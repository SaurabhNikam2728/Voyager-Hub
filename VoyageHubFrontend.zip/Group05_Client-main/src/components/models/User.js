export class Users{
    userId;
    userName;
    emailId;
    contactNumber;
    password;
    message;
}